﻿Windows: doubleclick the exe file


Linux & Mac: download & install Löve2D (instructions under https://www.love2d.org/). run with "love mazeShift.love"
