Windows: doubleclick the exe file
Linux & Max: download & install Löve2D (instructions under https://www.love2d.org/). run with "love mazeShift.love"
